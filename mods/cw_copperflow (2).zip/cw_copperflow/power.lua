local M = cw_copperflow
local maxp = M.power_max

-- oxidation penalty per stage
local OX_ATTEN = {
  [0] = 0, -- shiny
  [1] = 1, -- exposed
  [2] = 1, -- weathered
  [3] = 2, -- oxidized
}

-- how much this node eats (wires, logic blocks etc. can define _cf_loss = X)
local function node_loss(node)
  local def = node and minetest.registered_nodes[node.name]
  if not def then return 0 end
  return def._cf_loss or 0
end

-- wake neighbors for re-evaluation
local function poke_neighbors(p)
  for _,q in ipairs(cw_copperflow.adjacent6(p)) do
    local nt = minetest.get_node_timer(q)
    if nt then nt:start(0.05) end
  end
end

-- core recompute
function cw_copperflow.recompute_power(pos)
  local node = minetest.get_node_or_nil(pos); if not node then return end
  local def  = minetest.registered_nodes[node.name]; if not def then return end

  local meta = minetest.get_meta(pos)
  local self_out = tonumber(meta:get_string("cf_out")) or 0
  local best = self_out

  local ox   = cw_copperflow.get_ox_stage(pos)
  local ocost = OX_ATTEN[ox] or 0
  local self_loss = node_loss(node)
  local total_cost = ocost + self_loss

  -- consider neighbor inputs (with BP2 rule)
  for _,q in ipairs(cw_copperflow.adjacent6(pos)) do
    local nb = minetest.get_node_or_nil(q)
    local np = 0
    if nb then
      -- crossover has special axis-isolation power fetch
      if nb.name == "cw_copperflow:copper_crossover" then
        if q.x == pos.x then
          np = cw_copperflow.crossover_axis_power(q, "ns")
        elseif q.z == pos.z then
          np = cw_copperflow.crossover_axis_power(q, "ew")
        end
      else
        np = cw_copperflow.get_power(q)
      end
    end
    if np and np > 0 then
      local v = math.max(0, np - total_cost)
      if v > best then
        best = v
      end
    end
  end

  local prev = cw_copperflow.get_power(pos)
  if best ~= prev then
    cw_copperflow.set_power(pos, best, false)

    -- recolor if node supports lamp/wire tint
    if def.paramtype2 == "color" or def.paramtype2 == "colorwallmounted" or def.paramtype2 == "colorfacedir" then
      cw_copperflow.set_color_preserve_orientation(pos, cw_copperflow.param2_from_power(best))
    end

    poke_neighbors(pos)

    -- callback hook for actuators, lamps, etc
    if def.on_copper_signal then
      def.on_copper_signal(pos, node, best, prev)
    end
  end
end

function cw_copperflow.on_timer_conductive(pos)
  cw_copperflow.recompute_power(pos)
  return false
end

-- utility to inject a local outgoing value (lever, sensor, emitter etc)
function cw_copperflow.drive_output(pos, strength)
  local m = minetest.get_meta(pos)
  strength = math.max(0, math.min(strength or 0, maxp))
  local prev = tonumber(m:get_string("cf_out")) or 0
  if prev ~= strength then
    m:set_string("cf_out", tostring(strength))
    -- wake self + neighbors
    local t = minetest.get_node_timer(pos)
    if t then t:start(0.05) end
    for _,q in ipairs(cw_copperflow.adjacent6(pos)) do
      local qt = minetest.get_node_timer(q)
      if qt then qt:start(0.05) end
    end
  end
end

-- force evaluation of this and neighbors
function cw_copperflow.bump(pos)
  local nt = minetest.get_node_timer(pos)
  if nt then nt:start(0.05) end
  for _,q in ipairs(cw_copperflow.adjacent6(pos)) do
    local t = minetest.get_node_timer(q)
    if t then t:start(0.05) end
  end
end
