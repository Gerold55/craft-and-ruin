local G = cw_copperflow.groups
local function lamp_update(pos, node, now, prev)
  local is_on = now > 0
  local target = is_on and "cw_copperflow:copper_lamp_on" or "cw_copperflow:copper_lamp_off"
  if node.name ~= target then minetest.swap_node(pos, {name=target, param2=node.param2}) end
end
minetest.register_node("cw_copperflow:copper_lamp_off", {
  description = "Copper Lamp (Off)",
  tiles = {"cf_lamp_off.png"},
  groups = {cracky=2, [G.conductive]=1, [G.consumer]=1, [G.waxable]=1},
  paramtype = "light",
  paramtype2 = "facedir",
  _cf_loss = 0,
  light_source = 0,
  on_construct = function(pos) cw_copperflow.set_power(pos,0,false); minetest.get_node_timer(pos):start(0.05) end,
  on_timer = cw_copperflow.on_timer_conductive,
  on_copper_signal = lamp_update,
})
minetest.register_node("cw_copperflow:copper_lamp_on", {
  description = "Copper Lamp (On)",
  tiles = {"cf_lamp_on.png"},
  groups = {cracky=2, [G.conductive]=1, [G.consumer]=1, [G.waxable]=1, not_in_creative_inventory=1},
  paramtype = "light",
  paramtype2 = "facedir",
  _cf_loss = 0,
  light_source = minetest.LIGHT_MAX - 1,
  drop = "cw_copperflow:copper_lamp_off",
  on_construct = function(pos) cw_copperflow.set_power(pos,0,false); minetest.get_node_timer(pos):start(0.05) end,
  on_timer = cw_copperflow.on_timer_conductive,
  on_copper_signal = lamp_update,
})
minetest.register_alias_force("cw_copperflow:copper_lamp", "cw_copperflow:copper_lamp_off")
