local M = cw_copperflow
local OX = M.oxidation

minetest.register_abm({
  label = "CopperFlow Oxidation",
  nodenames = {"group:"..M.groups.waxable, "group:"..M.groups.wire, "group:"..M.groups.conductive},
  interval = 180,
  chance = 12,
  action = function(pos)
    if M.is_waxed(pos) then return end
    local s = M.get_ox_stage(pos)
    if s < OX.OXIDIZED then
      M.set_ox_stage(pos, s + 1)
      minetest.get_node_timer(pos):start(0.1)
    end
  end
})
