minetest.register_craft({
  output = "cw_copperflow:signal_gate",
  recipe = {
    {"cw_copperflow:copper_plate","cw_copperflow:gear","cw_copperflow:copper_plate"},
    {"", "cw_copperflow:resin", ""},
  }
})
minetest.register_alias("cw_copperflow:gate_oneway",    "cw_copperflow:signal_gate")
minetest.register_alias("cw_copperflow:gate_delay",     "cw_copperflow:signal_gate")
minetest.register_alias("cw_copperflow:gate_threshold", "cw_copperflow:signal_gate")
