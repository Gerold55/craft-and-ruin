local M = cw_copperflow
local G = M.groups

local function chan_key(color_idx, channel_id)
  color_idx = color_idx or 1
  channel_id = channel_id or "global"
  return color_idx..":"..channel_id
end

local function register_receiver(pos)
  local m = minetest.get_meta(pos)
  local color = m:get_int("color") or 1
  local ch    = m:get_string("channel"); if ch == "" then ch = "global" end
  local key   = chan_key(color, ch)
  cw_copperflow.wireless_registry[key] = cw_copperflow.wireless_registry[key] or {}
  cw_copperflow.wireless_registry[key][cw_copperflow.hashpos(pos)] = true
end
local function unregister_receiver(pos)
  local m = minetest.get_meta(pos)
  local color = m:get_int("color") or 1
  local ch    = m:get_string("channel"); if ch == "" then ch = "global" end
  local key   = chan_key(color, ch)
  local set   = cw_copperflow.wireless_registry[key]
  if set then set[cw_copperflow.hashpos(pos)] = nil end
end

minetest.register_craftitem("cw_copperflow:link_crystal", {
  description = "Link Crystal",
  inventory_image = "cf_link_crystal.png",
  stack_max = 1,
  on_place = function(itemstack, user, pointed)
    if pointed.type ~= "node" then return itemstack end
    local pos = pointed.under
    local n = minetest.get_node_or_nil(pos); if not n then return itemstack end

    local meta = itemstack:get_meta()
    local stored = meta:get_string("ch") ~= ""

    if n.name == "cw_copperflow:pulse_emitter" then
      local m = minetest.get_meta(pos)
      meta:set_string("ch", m:get_string("channel"))
      meta:set_int("color", m:get_int("color") or 1)
      meta:set_string("description", "Link Crystal (saved: "..(m:get_string("channel") or "global")..")")
      minetest.sound_play("default_place_node_hard", {pos=pos,gain=0.2})
    elseif n.name == "cw_copperflow:pulse_receiver" then
      if stored then
        local ch = meta:get_string("ch"); local color = meta:get_int("color")
        local m = minetest.get_meta(pos)
        unregister_receiver(pos)
        m:set_string("channel", ch)
        m:set_int("color", color)
        register_receiver(pos)
        minetest.get_node_timer(pos):start(0.05)
        minetest.sound_play("default_dig_crumbly", {pos=pos,gain=0.2})
      end
    end
    return itemstack
  end
})

minetest.register_node("cw_copperflow:pulse_emitter", {
  description = "Pulse Emitter (Wireless)",
  tiles = {"cf_emitter.png"},
  groups = {cracky=2, [G.emitter]=1, [G.conductive]=1, [G.waxable]=1},
  on_construct = function(pos)
    local m = minetest.get_meta(pos)
    m:set_string("channel", "global")
    m:set_int("color", 1)
    cw_copperflow.set_power(pos, 0, false)
  end,
  on_rightclick = function(pos, node, player)
    local m = minetest.get_meta(pos)
    local c = m:get_int("color") or 1
    c = (c % 16) + 1
    m:set_int("color", c)
    minetest.chat_send_player(player:get_player_name(), "Emitter color: "..(cw_copperflow.colors[c] or c))
  end,
  on_timer = cw_copperflow.on_timer_conductive,
  on_copper_signal = function(pos, node, now, prev)
    if now > 0 and prev == 0 then
      local m = minetest.get_meta(pos)
      local key = (m:get_int("color")..":"..(m:get_string("channel") or "global"))
      local set = cw_copperflow.wireless_registry[key] or {}
      local amp = 0
      for _,q in ipairs(cw_copperflow.adjacent6(pos)) do
        if minetest.get_node(q).name == "cw_copperflow:signal_amplifier" then amp = amp + 1 end
      end
      for h,_ in pairs(set) do
        local rpos = cw_copperflow.unhashpos(h)
        if rpos and minetest.get_node_or_nil(rpos) then
          cw_copperflow.drive_output(rpos, math.min(cw_copperflow.power_max, 8 + amp*2))
          minetest.after(0.15, function(p)
            if minetest.get_node_or_nil(p) then cw_copperflow.drive_output(p, 0); cw_copperflow.bump(p) end
          end, vector.new(rpos))
          minetest.get_node_timer(rpos):start(0.05)
        end
      end
      cw_copperflow.click(pos, "default_dug_node", 0.2)
    end
  end,
})

minetest.register_node("cw_copperflow:pulse_receiver", {
  description = "Pulse Receiver (Wireless)",
  tiles = {"cf_receiver.png"},
  groups = {cracky=2, [G.conductive]=1, [G.consumer]=1, [G.waxable]=1},
  on_construct = function(pos)
    local m = minetest.get_meta(pos)
    m:set_string("channel", "global")
    m:set_int("color", 1)
    cw_copperflow.set_power(pos, 0, false)
    register_receiver(pos)
  end,
  after_destruct = function(pos) unregister_receiver(pos) end,
  on_timer = cw_copperflow.on_timer_conductive,
})

minetest.register_node("cw_copperflow:signal_amplifier", {
  description = "Signal Amplifier (Wireless Boost)",
  tiles = {"cf_amplifier.png"},
  groups = {cracky=2, [G.waxable]=1},
})
