minetest.register_craftitem("cw_copperflow:resin", {description="Resin", inventory_image="cf_resin.png"})
minetest.register_craftitem("cw_copperflow:gear",  {description="Gear",  inventory_image="cf_gear.png"})
minetest.register_craftitem("cw_copperflow:crystal_core", {description="Crystal Core", inventory_image="cf_crystal_core.png"})
minetest.register_craftitem("cw_copperflow:copper_plate", {description="Copper Plate", inventory_image="cf_copper_plate.png"})
minetest.register_craftitem("cw_copperflow:copper_nugget", {description="Copper Nugget", inventory_image="cf_copper_nugget.png"})
minetest.register_craftitem("cw_copperflow:wax", {description="Wax", inventory_image="cf_wax.png"})

local I = "default:copper_ingot"
local W = "cw_copperflow:wax"
local R = "cw_copperflow:resin"
local G = "cw_copperflow:gear"
local P = "cw_copperflow:copper_plate"
local C = "cw_copperflow:crystal_core"
local N = "cw_copperflow:copper_nugget"
local CShard = "default:mese_crystal_fragment"
local CLump  = "default:clay_lump"
local WoodCrate = "default:chest"

minetest.register_craft({ output = "cw_copperflow:copper_wire_item 6",    recipe = {{I,R,I}} })
minetest.register_craft({ output = "cw_copperflow:insulated_wire_item 8", recipe = {{I,R,I}} })

minetest.register_craft({ output = "cw_copperflow:pulse_emitter",  recipe = {{I,C,I},{ "",I,"" }} })
minetest.register_craft({ output = "cw_copperflow:pulse_receiver", recipe = {{I,CShard,I},{ "",CLump,"" }} })
minetest.register_craft({ output = "cw_copperflow:link_crystal",   recipe = {{N,CShard,N}} })
minetest.register_craft({ output = "cw_copperflow:signal_amplifier", recipe = {{P,W,P},{ "",C,"" }} })

minetest.register_craft({ output="cw_copperflow:and", recipe={{G,P,G}} })
minetest.register_craft({ output="cw_copperflow:or",  recipe={{G,C,G}} })
minetest.register_craft({ output="cw_copperflow:not", recipe={{P,G,P}} })

minetest.register_craft({ output="cw_copperflow:actuator", recipe={{P,G,P},{I,"",I}} })
minetest.register_craft({ output="cw_copperflow:copper_dispenser", recipe={{P,C,P},{I,"",I}} })
minetest.register_craft({ output="cw_copperflow:copper_lamp_off", recipe={{P,"default:torch",P}} })

minetest.register_craft({
  output = "cw_copperflow:copper_feeder",
  recipe = {
    {"default:copper_ingot","","default:copper_ingot"},
    {"default:copper_ingot",WoodCrate,"default:copper_ingot"},
    {"","default:copper_ingot",""},
  }
})

minetest.register_craft({
  output = "cw_copperflow:copper_crossover 4",
  recipe = {
    {"cw_copperflow:copper_plate", "cw_copperflow:resin", "cw_copperflow:copper_plate"},
    {"", "default:copper_ingot", ""},
  }
})
