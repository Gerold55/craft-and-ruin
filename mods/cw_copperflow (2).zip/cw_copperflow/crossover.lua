local G = cw_copperflow.groups
local groove = 1/16
local rim    = 0.5 - 2*groove
local crossover_nodebox = {
  type = "fixed",
  fixed = {
    {-0.5, -0.5, -0.5,  0.5, -0.5 + groove, 0.5},
    {-groove, -0.5 + groove, -0.5,  groove, -0.5 + 3*groove, 0.5},
    {-0.5, -0.5 + groove, -groove,  0.5, -0.5 + 3*groove, groove},
    {-0.5, -0.5 + 3*groove, -0.5, -rim, -0.5 + 4*groove, 0.5},
    { rim, -0.5 + 3*groove, -0.5,  0.5, -0.5 + 4*groove, 0.5},
    {-0.5, -0.5 + 3*groove, -0.5,  0.5, -0.5 + 4*groove, -rim},
    {-0.5, -0.5 + 3*groove,  rim,  0.5, -0.5 + 4*groove, 0.5},
  }
}
local function max_power_at(list) local best = 0 for _,p in ipairs(list) do local v = cw_copperflow.get_power(p) or 0 if v > best then best = v end end return best end
local function ns_positions(pos) return { {x=pos.x, y=pos.y, z=pos.z-1}, {x=pos.x, y=pos.y, z=pos.z+1} } end
local function ew_positions(pos) return { {x=pos.x-1, y=pos.y, z=pos.z}, {x=pos.x+1, y=pos.y, z=pos.z} } end
minetest.register_node("cw_copperflow:copper_crossover", {
  description = "Copper Crossover (N–S + E–W in one block)",
  tiles = {"cf_crossover_top.png","cf_crossover_bottom.png","cf_crossover_side.png","cf_crossover_side.png","cf_crossover_side.png","cf_crossover_side.png"},
  drawtype = "nodebox",
  node_box = crossover_nodebox,
  collision_box = { type="fixed", fixed={{-0.5,-0.5,-0.5, 0.5, -0.5+4*groove, 0.5}} },
  selection_box = { type="fixed", fixed={{-0.5,-0.5,-0.5, 0.5, -0.5+4*groove, 0.5}} },
  paramtype = "light",
  paramtype2 = "color",
  palette   = "cf_power_palette.png",
  sunlight_propagates = true,
  walkable = true,
  groups   = {cracky=2, [G.conductive]=1, [G.waxable]=1},
  on_construct = function(pos)
    local m = minetest.get_meta(pos)
    m:set_int("p_ns", 0)
    m:set_int("p_ew", 0)
    minetest.get_node_timer(pos):start(0.05)
  end,
  on_timer = function(pos)
    local m  = minetest.get_meta(pos)
    local pns_in = max_power_at(ns_positions(pos))
    local pew_in = max_power_at(ew_positions(pos))
    local pns_prev = m:get_int("p_ns")
    local pew_prev = m:get_int("p_ew")
    if pns_in ~= pns_prev then m:set_int("p_ns", pns_in) end
    if pew_in ~= pew_prev then m:set_int("p_ew", pew_in) end
    local function poke(list) for _,q in ipairs(list) do local t = minetest.get_node_timer(q); if t then t:start(0.05) end end end
    if pns_in ~= pns_prev then poke(ns_positions(pos)) end
    if pew_in ~= pew_prev then poke(ew_positions(pos)) end
    local strongest = (pns_in > pew_in) and pns_in or pew_in
    local node = minetest.get_node(pos)
    node.param2 = cw_copperflow.param2_from_power(strongest)
    minetest.swap_node(pos, node)
    return true
  end,
})
function cw_copperflow.crossover_axis_power(pos, axis)
  local m = minetest.get_meta(pos)
  if axis == "ns" then return m:get_int("p_ns") or 0 end
  if axis == "ew" then return m:get_int("p_ew") or 0 end
  return 0
end
