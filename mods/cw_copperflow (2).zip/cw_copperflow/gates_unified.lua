local M, G = cw_copperflow, cw_copperflow.groups
local function fwd_dir(node)  return minetest.facedir_to_dir(node.param2) end
local function back_pos(pos, node) return vector.subtract(pos, fwd_dir(node)) end
local function front_pos(pos, node) return vector.add(pos, fwd_dir(node)) end
local DELAY_STEPS = {0.10, 0.20, 0.50, 1.00, 2.00}
local MODES = {"ONE-WAY", "DELAY", "THRESHOLD", "NOT"}
local function set_infotext(pos)
  local meta = minetest.get_meta(pos)
  local mode = meta:get_string("mode"); if mode == "" then mode = "ONE-WAY" end
  local info = "Signal Gate — "..mode
  if mode == "DELAY" then
    local idx = meta:get_int("idx"); if idx == 0 then idx = 3 end
    info = info .. ("  (%.2fs)"):format(DELAY_STEPS[idx] or 0.50)
  elseif mode == "THRESHOLD" then
    local th = meta:get_int("th"); if th == 0 then th = 8 end
    info = info .. ("  (≥ %d)"):format(th)
  end
  meta:set_string("infotext", info)
end
local function directional_eval(pos)
  local node = minetest.get_node_or_nil(pos); if not node then return end
  local meta = minetest.get_meta(pos)
  local mode = meta:get_string("mode"); if mode == "" then mode = "ONE-WAY" end
  local p_in  = cw_copperflow.get_power(back_pos(pos, node)) or 0
  local p_out = 0
  if mode == "ONE-WAY" then
    p_out = p_in
  elseif mode == "DELAY" then
    p_out = tonumber(meta:get_string("cf_out")) or 0
    local last = meta:get_int("last_in")
    if p_in ~= last then
      meta:set_int("last_in", p_in)
      local idx = meta:get_int("idx"); if idx == 0 then idx = 3 end
      local t   = DELAY_STEPS[idx] or 0.50
      local token = (minetest.get_us_time() .. minetest.pos_to_string(pos))
      meta:set_string("token", token)
      minetest.after(t, function(p, expect, val)
        local n = minetest.get_node_or_nil(p); if not n then return end
        local m = minetest.get_meta(p)
        if m:get_string("token") ~= expect then return end
        cw_copperflow.drive_output(p, val)
        local dir = minetest.facedir_to_dir(n.param2)
        for _,q in ipairs({vector.add(p, dir), vector.subtract(p, dir)}) do
          local tmr = minetest.get_node_timer(q); if tmr then tmr:start(0.05) end
        end
        local self_t = minetest.get_node_timer(p); if self_t then self_t:start(0.05) end
      end, vector.new(pos), token, p_in)
    end
  elseif mode == "THRESHOLD" then
    local th = meta:get_int("th"); if th == 0 then th = 8 end
    p_out = (p_in >= th) and M.power_max or 0
  elseif mode == "NOT" then
    p_out = (p_in > 0) and 0 or M.power_max
  end
  local prev = cw_copperflow.get_power(pos)
  if p_out ~= prev then
    cw_copperflow.set_power(pos, p_out, false)
    local f = front_pos(pos, node); local b = back_pos(pos, node)
    local tf = minetest.get_node_timer(f); if tf then tf:start(0.05) end
    local tb = minetest.get_node_timer(b); if tb then tb:start(0.05) end
    local def = minetest.registered_nodes[node.name]
    if def and def.on_copper_signal then def.on_copper_signal(pos, node, p_out, prev) end
  end
end
minetest.register_node("cw_copperflow:signal_gate", {
  description = "Signal Gate (One-Way / Delay / Threshold / NOT)",
  tiles = {"cf_gate_top.png","cf_gate_bottom.png","cf_gate_side.png","cf_gate_side.png","cf_gate_front.png","cf_gate_back.png"},
  drawtype   = "normal",
  paramtype2 = "facedir",
  groups     = {cracky=2, [G.conductive]=1, [G.consumer]=1, [G.waxable]=1},
  _cf_loss   = 0,
  on_construct = function(pos)
    local m = minetest.get_meta(pos)
    m:set_string("mode", "ONE-WAY")
    m:set_int("idx", 3)
    m:set_int("th",  8)
    m:set_int("last_in", -1)
    m:set_string("token", "")
    set_infotext(pos)
    minetest.get_node_timer(pos):start(0.05)
  end,
  on_punch = function(pos, node, puncher)
    local m = minetest.get_meta(pos)
    local cur = m:get_string("mode"); if cur == "" then cur = "ONE-WAY" end
    local MODES = {"ONE-WAY","DELAY","THRESHOLD","NOT"}
    local i = 1; for k,v in ipairs(MODES) do if v == cur then i = k break end end
    i = (i % #MODES) + 1
    local nxt = MODES[i]
    m:set_string("mode", nxt)
    cw_copperflow.drive_output(pos, 0)
    set_infotext(pos)
    minetest.get_node_timer(pos):start(0.05)
    if puncher then minetest.chat_send_player(puncher:get_player_name(), "Signal Gate mode: "..nxt) end
  end,
  on_rightclick = function(pos, node, clicker)
    local m = minetest.get_meta(pos)
    local mode = m:get_string("mode"); if mode == "" then mode = "ONE-WAY" end
    if mode == "DELAY" then
      local idx = m:get_int("idx"); idx = (idx % 5) + 1
      m:set_int("idx", idx)
      if clicker then minetest.chat_send_player(clicker:get_player_name(), ("Delay set to %.2fs"):format(({0.10,0.20,0.50,1.00,2.00})[idx])) end
    elseif mode == "THRESHOLD" then
      local th = m:get_int("th"); th = (th % 15) + 1
      m:set_int("th", th)
      if clicker then minetest.chat_send_player(clicker:get_player_name(), "Threshold set to ≥ "..th) end
    else
      if clicker then minetest.chat_send_player(clicker:get_player_name(), mode.." mode has no adjustable parameter.") end
    end
    set_infotext(pos)
    minetest.get_node_timer(pos):start(0.05)
  end,
  on_timer = function(pos) directional_eval(pos); return true end,
  on_destruct = function(pos) cw_copperflow.bump(pos) end,
})
