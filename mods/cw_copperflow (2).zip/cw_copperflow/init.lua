local MOD = minetest.get_current_modname()
local MP  = minetest.get_modpath(MOD)

cw_copperflow = {
  modname = MOD,
  power_max = 15,
  groups = {
    conductive = "cf_conductive",
    emitter    = "cf_emitter",
    consumer   = "cf_consumer",
    logic      = "cf_logic",
    wire       = "cf_wire",
    waxable    = "cf_waxable",
  },
  oxidation = { NONE=0, EXPOSED=1, WEATHERED=2, OXIDIZED=3 },
  colors = {
    "white","orange","magenta","light_blue","yellow","lime","pink","gray",
    "light_gray","cyan","purple","blue","brown","green","red","black"
  },
  wireless_registry = {},
}

dofile(MP.."/util.lua")
dofile(MP.."/power.lua")
dofile(MP.."/oxidation.lua")
dofile(MP.."/wire.lua")
dofile(MP.."/logic.lua")
dofile(MP.."/actuator.lua")
dofile(MP.."/sensors.lua")
dofile(MP.."/wireless.lua")
dofile(MP.."/machines.lua")
dofile(MP.."/gates_unified.lua")
dofile(MP.."/crossover.lua")
dofile(MP.."/lamp.lua")
dofile(MP.."/lever.lua")
dofile(MP.."/crafting.lua")
dofile(MP.."/gates_recipes.lua")

minetest.log("action", "[cw_copperflow] loaded")
