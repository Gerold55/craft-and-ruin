local M = cw_copperflow
local G = M.groups

minetest.register_node("cw_copperflow:sensor_plate", {
  description = "Sensor Plate",
  tiles = {"cf_sensor_plate.png"},
  drawtype = "nodebox",
  paramtype = "light",
  node_box = {type="fixed", fixed={{-0.5,-0.5,-0.5,0.5,-0.4,0.5}}},
  groups = {cracky=2, [G.emitter]=1, [G.conductive]=1, [G.waxable]=1},
  on_construct = function(pos)
    minetest.get_meta(pos):set_string("radius", "1")
    minetest.get_node_timer(pos):start(0.2)
  end,
  on_timer = function(pos)
    local hit = false
    local objs = minetest.get_objects_inside_radius(pos, 0.6)
    for _,o in ipairs(objs) do
      if o:is_player() then
        local p = o:get_pos()
        if p and math.floor(p.x) == pos.x and math.floor(p.z) == pos.z and p.y >= pos.y and p.y <= pos.y + 1.2 then
          hit = true
          break
        end
      end
    end
    cw_copperflow.drive_output(pos, hit and cw_copperflow.power_max or 0)
    cw_copperflow.recompute_power(pos)
    return true
  end
})

minetest.register_node("cw_copperflow:copper_pulse_sensor", {
  description = "Copper Pulse Sensor",
  tiles = {"cf_pulse_sensor.png"},
  groups = {cracky=2, [G.emitter]=1, [G.conductive]=1, [G.waxable]=1},
  paramtype2 = "facedir",
  on_construct = function(pos)
    local m = minetest.get_meta(pos)
    m:set_string("last_name","")
    m:set_int("last_p2",-1)
    minetest.get_node_timer(pos):start(0.3)
  end,
  on_timer = function(pos)
    local node = minetest.get_node(pos)
    local dir  = minetest.facedir_to_dir(node.param2)
    local watched = vector.add(pos, dir)
    local wn = minetest.get_node_or_nil(watched)
    local m  = minetest.get_meta(pos)
    local ln = m:get_string("last_name")
    local lp = m:get_int("last_p2")

    local cname = wn and wn.name or "air"
    local cp2   = wn and wn.param2 or 0

    if cname ~= ln or cp2 ~= lp then
      cw_copperflow.drive_output(pos, cw_copperflow.power_max)
      minetest.after(0.1, function(p)
        if minetest.get_node_or_nil(p) then cw_copperflow.drive_output(p, 0); cw_copperflow.bump(p) end
      end, vector.new(pos))
      m:set_string("last_name", cname)
      m:set_int("last_p2", cp2)
    end

    cw_copperflow.recompute_power(pos)
    return true
  end
})
