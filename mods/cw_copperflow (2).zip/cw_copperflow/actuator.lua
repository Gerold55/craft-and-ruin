local G = cw_copperflow.groups

minetest.register_node("cw_copperflow:actuator", {
  description = "Copper Actuator",
  tiles = {"cf_actuator_top.png","cf_actuator_bottom.png","cf_actuator_side.png^cf_actuator_head.png"},
  paramtype2 = "facedir",
  groups = {cracky=2, [G.consumer]=1, [G.conductive]=1, [G.waxable]=1},
  on_construct = function(pos)
    cw_copperflow.set_power(pos, 0, false)
    minetest.get_node_timer(pos):start(0.05)
  end,
  on_timer = function(pos)
    local pow = cw_copperflow.get_power(pos)
    local node = minetest.get_node(pos)
    local dir = minetest.facedir_to_dir(node.param2)
    local front = vector.add(pos, dir)
    if pow > 0 then
      local nfront = minetest.get_node_or_nil(front)
      local ahead  = vector.add(front, dir)
      if nfront and nfront.name ~= "air" then
        local def = minetest.registered_nodes[nfront.name]
        if def and def.groups and (def.groups.movable or def.groups.crumbly or def.groups.choppy) then
          local nahead = minetest.get_node_or_nil(ahead)
          if nahead and (nahead.name == "air" or (minetest.registered_nodes[nahead.name] or {}).buildable_to) then
            minetest.swap_node(ahead, nfront)
            minetest.set_node(front, {name="air"})
            minetest.sound_play("default_dug_node", {pos=ahead, gain=0.3})
          end
        end
      end
    end
    return true
  end,
  on_copper_signal = function(pos, node, now, prev)
    if (prev or 0) == 0 and now > 0 then minetest.get_node_timer(pos):start(0.05) end
  end,
})
