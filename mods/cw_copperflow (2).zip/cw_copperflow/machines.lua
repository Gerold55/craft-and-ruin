local M = cw_copperflow
local G = cw_copperflow.groups
local function facedir_dir(node) return minetest.facedir_to_dir(node.param2) end
local function pull_one_from_above_into(pos)
  local above = vector.add(pos, {x=0,y=1,z=0})
  local inv_above = minetest.get_inventory({type="node", pos=above})
  if not inv_above then return false end
  local inv_self = minetest.get_inventory({type="node", pos=pos})
  if not inv_self then return false end
  for _,lst in ipairs({"main","dst","src"}) do
    local size = inv_above:get_size(lst) or 0
    if size > 0 then
      for i=1,size do
        local st = inv_above:get_stack(lst, i)
        if not st:is_empty() then
          local one = st:peek_item(1)
          local leftover = inv_self:add_item("main", one)
          if leftover:is_empty() then
            st:take_item(1)
            inv_above:set_stack(lst, i, st)
            return true
          end
        end
      end
    end
  end
  return false
end
local function push_one_to_inventory(pos_from, list_from, pos_dst)
  local inv_from = minetest.get_inventory({type="node", pos=pos_from})
  if not inv_from then return false end
  local inv_to = minetest.get_inventory({type="node", pos=pos_dst})
  if not inv_to then return false end
  if (inv_to:get_size("main") or 0) <= 0 then return false end
  local size = inv_from:get_size(list_from) or 0
  for i=1,size do
    local st = inv_from:get_stack(list_from, i)
    if not st:is_empty() then
      local one = st:peek_item(1)
      local leftover = inv_to:add_item("main", one)
      if leftover:is_empty() then
        st:take_item(1)
        inv_from:set_stack(list_from, i, st)
        return true
      end
    end
  end
  return false
end
local function is_item_entity(obj)
  local e = obj and obj:get_luaentity()
  if not e then return false end
  return e.name == "__builtin:item" or e.name == "item" or e.itemstring ~= nil or e.item ~= nil
end
local function get_entity_itemstack(obj)
  local e = obj:get_luaentity()
  if e.get_item then local st = e:get_item(); if st then return st end end
  local s = e.itemstring or e.item
  if type(s) == "string" then return ItemStack(s) end
  return ItemStack("")
end
local function set_entity_itemstack(obj, stack)
  local e = obj:get_luaentity()
  if e.set_item then e:set_item(stack); return end
  local s = (stack and not stack:is_empty()) and stack:to_string() or ""
  if s == "" then obj:remove() else e.itemstring = s end
end
local function suck_items_from_top(pos)
  local top_center = {x=pos.x, y=pos.y + 0.6, z=pos.z}
  local objs = minetest.get_objects_inside_radius(top_center, 0.9)
  if not objs or #objs == 0 then return false end
  local inv = minetest.get_inventory({type="node", pos=pos})
  if not inv then return false end
  local changed = false
  for _,obj in ipairs(objs) do
    if is_item_entity(obj) then
      local st = get_entity_itemstack(obj)
      if not st:is_empty() then
        local leftover = inv:add_item("main", st)
        if leftover:is_empty() then obj:remove(); changed = true
        elseif leftover:get_count() ~= st:get_count() then set_entity_itemstack(obj, leftover); changed = true end
      end
    end
  end
  return changed
end
local FEEDER_FORMSPEC = table.concat({
  "formspec_version[4]",
  "size[10,10]",
  "label[0.6,0.6;Copper Feeder]",
  "box[0.5,1.0;9,0.05;#a56c43ff]",
  "list[current_name;main;1,1.5;8,1;]",
  "box[0.5,3.0;9,0.05;#a56c43ff]",
  "label[0.6,3.4;Your Inventory]",
  "list[current_player;main;1,3.9;8,4;]",
  "listring[current_name;main]",
  "listring[current_player;main]",
}, "")
local function feeder_on_place(itemstack, placer, pointed)
  if pointed and pointed.type == "node" then
    local under, above = pointed.under, pointed.above
    local dir = vector.direction(under, above)
    local param2 = minetest.dir_to_facedir(dir, true)
    local stack = ItemStack(itemstack)
    local def = stack:get_definition()
    local pos = above
    if minetest.is_protected(pos, placer:get_player_name()) then return itemstack end
    local ocup = minetest.get_node_or_nil(pos)
    if ocup and (minetest.registered_nodes[ocup.name] or {}).buildable_to == false then return itemstack end
    minetest.set_node(pos, {name=def.name, param2=param2})
    if not minetest.is_creative_enabled(placer:get_player_name()) then itemstack:take_item() end
    local defn = minetest.registered_nodes[def.name]; if defn and defn.on_construct then defn.on_construct(pos) end
    return itemstack
  end
  return minetest.item_place(itemstack, placer, pointed)
end
minetest.register_node("cw_copperflow:copper_feeder", {
  description = "Copper Feeder",
  tiles = {
    "cf_feeder_top.png","cf_feeder_bottom.png",
    "cf_feeder_side.png","cf_feeder_side.png",
    "cf_feeder_front.png","cf_feeder_back.png",
  },
  drawtype = "nodebox",
  use_texture_alpha = "clip",
  paramtype = "light",
  paramtype2 = "facedir",
  legacy_facedir_simple = false,
  groups = {cracky=2, [G.consumer]=1, [G.conductive]=1, [G.waxable]=1},
  _cf_loss = 0,
  on_place = feeder_on_place,
  node_box = { type = "fixed", fixed = {
    {-0.5,-0.5,-0.5,0.5,-0.4375,0.5},
    {-0.375,-0.4375,-0.375,0.375,0.125,0.375},
    {-0.375,0.125,-0.375,0.375,0.25,-0.3125},
    {-0.375,0.125,0.3125,0.375,0.25,0.375},
    {-0.375,0.125,-0.3125,-0.3125,0.25,0.3125},
    {0.3125,0.125,-0.3125,0.375,0.25,0.3125},
    {-0.25,0.125,-0.25,0.25,0.1875,0.25},
    {-0.1875,0.0625,-0.1875,0.1875,0.125,0.1875},
    {-0.125,0.0,-0.125,0.125,0.0625,0.125},
    {-0.125,-0.0625,0.375,0.125,0.1875,0.5},
  }},
  collision_box = { type="fixed", fixed = {
    {-0.5,-0.5,-0.5,0.5,0.25,0.5},
    {-0.125,-0.0625,0.375,0.125,0.1875,0.5},
  }},
  selection_box = { type="fixed", fixed = {
    {-0.5,-0.5,-0.5,0.5,0.25,0.5},
    {-0.125,-0.0625,0.375,0.125,0.1875,0.5},
  }},
  on_construct = function(pos)
    local m = minetest.get_meta(pos)
    m:set_string("infotext", "Copper Feeder (Sucks from top; Powered = hold; outputs only to storage ahead)")
    m:set_string("formspec", FEEDER_FORMSPEC)
    local inv = m:get_inventory(); inv:set_size("main", 8)
    minetest.get_node_timer(pos):start(0.25)
  end,
  on_rightclick = function(pos, node, player)
    minetest.show_formspec(player:get_player_name(),
      "cw_copperflow:feeder_"..minetest.pos_to_string(pos), FEEDER_FORMSPEC)
  end,
  allow_metadata_inventory_put    = function(pos, list, idx, stack, player) return stack:get_count() end,
  allow_metadata_inventory_take   = function(pos, list, idx, stack, player) return stack:get_count() end,
  allow_metadata_inventory_move   = function(pos, fl, fi, tl, ti, n, player) return n end,
  on_timer = function(pos)
    local pow = cw_copperflow.get_power(pos) or 0
    local node = minetest.get_node(pos)
    local dir  = minetest.facedir_to_dir(node.param2)
    local front= vector.add(pos, dir)
    suck_items_from_top(pos)
    pull_one_from_above_into(pos)
    if pow <= 0 then push_one_to_inventory(pos, "main", front) end
    return true
  end,
  on_copper_signal = function(pos) local t = minetest.get_node_timer(pos); if t then t:start(0.05) end end,
  on_destruct = function(pos) cw_copperflow.bump(pos) end,
})
minetest.register_alias("cw_copperflow:copper_hopper", "cw_copperflow:copper_feeder")
minetest.register_node("cw_copperflow:copper_dispenser", {
  description = "Copper Dispenser",
  tiles = {"cf_dispenser_top.png","cf_dispenser_bottom.png","cf_dispenser_side.png^cf_dispenser_front.png"},
  groups = {cracky=2, [G.consumer]=1, [G.conductive]=1, [G.waxable]=1},
  paramtype2 = "facedir",
  on_construct = function(pos)
    local inv = minetest.get_meta(pos):get_inventory()
    inv:set_size("main", 9)
  end,
  on_copper_signal = function(pos, node, now, prev)
    if now > 0 and prev == 0 then
      local inv = minetest.get_meta(pos):get_inventory()
      for i=1,inv:get_size("main") do
        local st = inv:get_stack("main", i)
        if not st:is_empty() then
          local dir = minetest.facedir_to_dir(node.param2)
          local drop = vector.add(pos, dir)
          local one = st:take_item(1)
          inv:set_stack("main", i, st)
          local obj = minetest.add_item(drop, one)
          if obj then obj:set_velocity(vector.multiply(dir, 6)) end
          minetest.sound_play("default_place_node", {pos=pos,gain=0.3})
          break
        end
      end
    end
  end,
})
