-- cw_copperflow/lever.lua
-- Copper Lever: wall/floor/ceiling mountable toggle that emits full-strength CopperFlow power.

local M, G = cw_copperflow, cw_copperflow.groups

-- Simple plate + handle nodebox that depends on which face we're mounted to.
local TH  = 0.10   -- plate thickness
local PAD = 0.02   -- tiny offset from face to avoid z-fighting

-- Plate slab anchored to the mounting face
local function plate(face)
  -- face (wallmounted): 0=top, 1=bottom, 2=+X (east), 3=-X (west), 4=+Z (south), 5=-Z (north)
  if face == 1 then
    -- bottom (floor)
    return { -0.25, -0.5+PAD, -0.25,  0.25, -0.5+PAD+TH,  0.25 }
  elseif face == 0 then
    -- top (ceiling)
    return { -0.25,  0.5-PAD-TH, -0.25,  0.25, 0.5-PAD, 0.25 }
  elseif face == 2 then
    -- +X (east wall)
    return { -0.5+PAD, -0.25, -0.25,  -0.5+PAD+TH, 0.25, 0.25 }
  elseif face == 3 then
    -- -X (west wall)
    return {  0.5-PAD-TH, -0.25, -0.25,  0.5-PAD, 0.25, 0.25 }
  elseif face == 4 then
    -- +Z (south wall)
    return { -0.25, -0.25,  0.5-PAD-TH,  0.25, 0.25, 0.5-PAD }
  else
    -- -Z (north wall)
    return { -0.25, -0.25, -0.5+PAD,  0.25, 0.25, -0.5+PAD+TH }
  end
end

-- Handle rod that leans out differently when ON vs OFF
local function handle(face, on)
  local t = on and 0.28 or 0.18 -- extend a bit further when ON
  if face == 1 then
    -- floor
    return { -0.05, -0.5+PAD+TH, -0.05,  0.05, -0.5+PAD+TH+t, 0.05 }
  elseif face == 0 then
    -- ceiling
    return { -0.05,  0.5-PAD-TH-t, -0.05,  0.05, 0.5-PAD-TH, 0.05 }
  elseif face == 2 then
    -- +X (east wall)
    return { -0.5+PAD+TH, -0.05, -0.05,  -0.5+PAD+TH+t, 0.05, 0.05 }
  elseif face == 3 then
    -- -X (west wall)
    return {  0.5-PAD-TH-t, -0.05, -0.05,  0.5-PAD-TH, 0.05, 0.05 }
  elseif face == 4 then
    -- +Z (south wall)
    return { -0.05, -0.05,  0.5-PAD-TH-t,  0.05, 0.05, 0.5-PAD-TH }
  else
    -- -Z (north wall)
    return { -0.05, -0.05, -0.5+PAD+TH,   0.05, 0.05, -0.5+PAD+TH+t }
  end
end

local function make_nodebox(face, on)
  return { type = "fixed", fixed = { plate(face), handle(face, on) } }
end

-- Toggle helper. When ON emit full strength (15), when OFF emit 0.
local function toggle(pos, node, turn_on)
  local on = turn_on
  if on == nil then
    on = (node.name == "cw_copperflow:lever_off")
  end
  local face = node.param2 % 32
  local newname = on and "cw_copperflow:lever_on" or "cw_copperflow:lever_off"

  if node.name ~= newname then
    -- keep the same orientation
    minetest.swap_node(pos, { name = newname, param2 = node.param2 })
  end

  -- emit power
  cw_copperflow.drive_output(pos, on and cw_copperflow.power_max or 0)
  cw_copperflow.bump(pos)
end

-- Common behavior used by both ON/OFF variants
local common = {
  drawtype   = "nodebox",
  paramtype  = "light",
  paramtype2 = "wallmounted",  -- we mount on faces (floor/ceiling/walls)
  sunlight_propagates = true,
  walkable   = false,

  groups     = { cracky=2, [G.emitter]=1, [G.conductive]=1, [G.waxable]=1 },

  on_construct = function(pos)
    -- default to off until toggled (lever_off starts with cf_out=0; lever_on sets to max in its own on_construct)
    cw_copperflow.set_power(pos, 0, false)
    local t = minetest.get_node_timer(pos)
    if t then t:start(0.05) end
  end,

  on_timer = function(pos)
    -- stay reactive to network changes (BP2 power recompute)
    cw_copperflow.recompute_power(pos)
    return false
  end,

  -- Toggle by right click or punch
  on_rightclick = function(pos, node, clicker) toggle(pos, node) end,
  on_punch      = function(pos, node, puncher) toggle(pos, node) end,
}

-- OFF state
minetest.register_node("cw_copperflow:lever_off", setmetatable({
  description = "Copper Lever",
  tiles = { "cf_lever_base.png" },

  -- Nodebox is face-dependent. We update it on placement to match the mounted face.
  node_box = make_nodebox(1, false), -- temporary; replaced in on_place
  selection_box = { type="fixed", fixed = { -0.35, -0.5, -0.35, 0.35, 0.0, 0.35 } },

  -- Custom placement so it mounts to the clicked face and we set the right nodebox
  on_place = function(itemstack, placer, pointed)
    if pointed and pointed.type == "node" then
      local face = minetest.dir_to_wallmounted(vector.subtract(pointed.under, pointed.above))
      local pos  = pointed.above
      local pname = placer and placer:get_player_name() or ""
      if minetest.is_protected(pos, pname) then return itemstack end

      minetest.set_node(pos, { name = "cw_copperflow:lever_off", param2 = face })

      -- Update the registered node's node_box *globally* to reflect the most recent mounted face.
      -- This is a Minetest limitation workaround for face-dependent nodeboxes with wallmounted nodes.
      local def = minetest.registered_nodes["cw_copperflow:lever_off"]
      def.node_box = make_nodebox(face, false)

      cw_copperflow.bump(pos)
      if not minetest.is_creative_enabled(pname) then itemstack:take_item() end
      return itemstack
    end
    return minetest.item_place(itemstack, placer, pointed)
  end,
}, { __index = common }))

-- ON state
minetest.register_node("cw_copperflow:lever_on", setmetatable({
  description = "Copper Lever (ON)",
  tiles = { "cf_lever_base.png^[brighten" },
  drop  = "cw_copperflow:lever_off",
  groups = { cracky=2, [G.emitter]=1, [G.conductive]=1, [G.waxable]=1, not_in_creative_inventory=1 },

  node_box = make_nodebox(1, true), -- temporary; kept for previews
  selection_box = { type="fixed", fixed = { -0.35, -0.5, -0.35, 0.35, 0.0, 0.35 } },

  on_construct = function(pos)
    -- ON variant emits immediately
    cw_copperflow.drive_output(pos, cw_copperflow.power_max)
    local t = minetest.get_node_timer(pos)
    if t then t:start(0.05) end

    -- Ensure the nodebox matches the mounted face if placed via swap
    local node = minetest.get_node(pos)
    local face = node.param2 % 32
    local def  = minetest.registered_nodes["cw_copperflow:lever_on"]
    def.node_box = make_nodebox(face, true)
  end,
}, { __index = common }))
