local M = cw_copperflow
local G = M.groups

local function make_logic(name, desc, fn)
  minetest.register_node("cw_copperflow:"..name, {
    description = "Logic Gear ("..desc..")",
    tiles = {"cf_logic_"..name..".png"},
    groups = {cracky=2, [G.logic]=1, [G.conductive]=1, [G.waxable]=1},
    on_construct = function(pos) minetest.get_node_timer(pos):start(0.05) end,
    on_timer = function(pos)
      local inputs = {}
      for _,q in ipairs(cw_copperflow.adjacent6(pos)) do
        table.insert(inputs, cw_copperflow.get_power(q))
      end
      local out = fn(inputs)
      cw_copperflow.drive_output(pos, out)
      cw_copperflow.recompute_power(pos)
      return true
    end,
  })
end

make_logic("and", "AND", function(ins)
  local m = cw_copperflow.power_max
  for _,v in ipairs(ins) do if v <= 0 then return 0 end m = math.min(m, v) end
  return m
end)

make_logic("or", "OR", function(ins)
  local b = 0; for _,v in ipairs(ins) do b = math.max(b, v) end; return b
end)

make_logic("not", "NOT", function(ins)
  local b = 0; for _,v in ipairs(ins) do b = math.max(b, v) end
  return (b>0) and 0 or cw_copperflow.power_max
end)
