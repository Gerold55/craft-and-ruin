local M = cw_copperflow

function M.hashpos(p) return minetest.pos_to_string(p) end
function M.unhashpos(s) return minetest.string_to_pos(s) end

function M.adjacent6(p)
  return {
    {x=p.x+1,y=p.y,z=p.z},{x=p.x-1,y=p.y,z=p.z},
    {x=p.x,y=p.y+1,z=p.z},{x=p.x,y=p.y-1,z=p.z},
    {x=p.x,y=p.y,z=p.z+1},{x=p.x,y=p.y,z=p.z-1},
  }
end

function M.get_power(p)
  local n = minetest.get_node_or_nil(p); if not n then return 0 end
  local m = minetest.get_meta(p)
  return tonumber(m:get_string("cf_power")) or 0
end

function M.set_power(p, val, fire_timer)
  local n = minetest.get_node_or_nil(p); if not n then return end
  local m = minetest.get_meta(p)
  local v = math.max(0, math.min(val or 0, cw_copperflow.power_max))
  m:set_string("cf_power", tostring(v))
  if fire_timer then minetest.get_node_timer(p):start(0.05) end
end

function M.get_ox_stage(p)
  local m = minetest.get_meta(p)
  return tonumber(m:get_string("cf_ox")) or 0
end
function M.set_ox_stage(p, s)
  local m = minetest.get_meta(p); m:set_string("cf_ox", tostring(s or 0))
end

function M.is_waxed(p) return (minetest.get_meta(p):get_int("cf_waxed") or 0) == 1 end
function M.set_waxed(p, on) minetest.get_meta(p):set_int("cf_waxed", on and 1 or 0) end

function M.param2_from_power(power) return math.max(0, math.min(power, 15)) end

function cw_copperflow.set_color_preserve_orientation(pos, color_index)
  local n = minetest.get_node_or_nil(pos); if not n then return end
  local def = minetest.registered_nodes[n.name]; if not def then return end
  local idx = math.max(0, math.min(31, color_index or 0))
  if def.paramtype2 == "colorwallmounted" or def.paramtype2 == "colorfacedir" then
    local orient = n.param2 % 32
    n.param2 = orient + idx * 32
    minetest.swap_node(pos, n)
  elseif def.paramtype2 == "color" then
    n.param2 = idx
    minetest.swap_node(pos, n)
  end
end

function M.click(p, name, gain)
  minetest.sound_play(name or "default_place_node_hard", {pos=p, gain=gain or 0.1}, true)
end

function cw_copperflow.poke_neighbors3(pos)
  for dx=-1,1 do for dy=-1,1 do for dz=-1,1 do
    local q = {x=pos.x+dx,y=pos.y+dy,z=pos.z+dz}
    local t = minetest.get_node_timer(q)
    if t then t:start(0.05) end
  end end end
end
