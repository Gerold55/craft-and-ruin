-- wire.lua
local M = cw_copperflow
local G = M.groups

-- tiny thickness so players don’t collide with it
local THICK, PAD = 0.02, 0.002

local function hasbit(x, b) return (x % (b * 2)) >= b end
local function setbit(x, b) return hasbit(x, b) and x or (x + b) end

-- Build a skinny rectangle on a given face (0..5 = ceiling, floor, +X, -X, +Z, -Z in wallmounted terms)
local function rect2face(face, u1, v1, u2, v2)
  local x1 = (u1 / 16) - 0.5; local x2 = (u2 / 16) - 0.5
  local y1 = (v1 / 16) - 0.5; local y2 = (v2 / 16) - 0.5
  if face == 1 then -- floor
    return { x1, -0.5 + PAD, y1,  x2, -0.5 + PAD + THICK, y2 }
  elseif face == 0 then -- ceiling
    return { x1,  0.5 - PAD - THICK, y1,  x2, 0.5 - PAD, y2 }
  elseif face == 2 then -- +X wall
    return { -0.5 + PAD, y1, x1,  -0.5 + PAD + THICK, y2, x2 }
  elseif face == 3 then -- -X wall
    return {  0.5 - PAD - THICK, y1, x1,   0.5 - PAD, y2, x2 }
  elseif face == 4 then -- +Z wall
    return { x1, y1,  0.5 - PAD - THICK,  x2, y2, 0.5 - PAD }
  else -- face == 5  -- -Z wall
    return { x1, y1, -0.5 + PAD,  x2, y2, -0.5 + PAD + THICK }
  end
end

local function core(face)         return rect2face(face, 7, 7, 9, 9) end
local function arm(face, dirbit)  -- 1=N,2=E,4=S,8=W in the dust’s local 2D
  if     dirbit == 1 then return rect2face(face, 7, 0,  9, 8)
  elseif dirbit == 2 then return rect2face(face, 8, 7, 16, 9)
  elseif dirbit == 4 then return rect2face(face, 7, 8,  9, 16)
  else                    return rect2face(face, 0, 7,  8, 9) end
end

-- For each face build 16 nodeboxes (center only + 4 arms)
local FACE_BOXES = {}
for face = 0,5 do
  local face_boxes = {}
  for mask = 0,15 do
    local parts = { core(face) }
    if hasbit(mask,1) then parts[#parts+1] = arm(face,1) end
    if hasbit(mask,2) then parts[#parts+1] = arm(face,2) end
    if hasbit(mask,4) then parts[#parts+1] = arm(face,4) end
    if hasbit(mask,8) then parts[#parts+1] = arm(face,8) end
    face_boxes[mask] = { type="fixed", fixed = parts }
  end
  FACE_BOXES[face] = face_boxes
end

-- 2D neighbor layout per face (local N,E,S,W vectors in world coords)
local NEIGH = {
  [1] = { {dx=0,dy=0,dz=-1,bit=1}, {dx=1,dy=0,dz=0,bit=2}, {dx=0,dy=0,dz=1,bit=4}, {dx=-1,dy=0,dz=0,bit=8} }, -- floor
  [0] = { {dx=0,dy=0,dz=-1,bit=1}, {dx=1,dy=0,dz=0,bit=2}, {dx=0,dy=0,dz=1,bit=4}, {dx=-1,dy=0,dz=0,bit=8} }, -- ceiling
  [2] = { {dx=0,dy=1,dz=0,bit=1},  {dx=0,dy=0,dz=1,bit=2}, {dx=0,dy=-1,dz=0,bit=4}, {dx=0,dy=0,dz=-1,bit=8} }, -- +X wall
  [3] = { {dx=0,dy=1,dz=0,bit=1},  {dx=0,dy=0,dz=-1,bit=2},{dx=0,dy=-1,dz=0,bit=4}, {dx=0,dy=0,dz=1,bit=8} }, -- -X wall
  [4] = { {dx=1,dy=0,dz=0,bit=1},  {dx=0,dy=1,dz=0,bit=2}, {dx=-1,dy=0,dz=0,bit=4}, {dx=0,dy=-1,dz=0,bit=8} }, -- +Z wall
  [5] = { {dx=-1,dy=0,dz=0,bit=1}, {dx=0,dy=1,dz=0,bit=2}, {dx=1,dy=0,dz=0,bit=4},  {dx=0,dy=-1,dz=0,bit=8} }, -- -Z wall
}

local function is_wire(name) return name and name:find("^cw_copperflow:.*_wire_f%d+_m%d+$") ~= nil end

-- Compute which arms we should draw on THIS face
local function compute_mask(pos, face)
  local mask = 0
  for _,d in ipairs(NEIGH[face] or {}) do
    local q = {x=pos.x+d.dx, y=pos.y+d.dy, z=pos.z+d.dz}
    local n = minetest.get_node_or_nil(q)
    if n then
      if is_wire(n.name) then
        local f2 = n.param2 % 32        -- orientation lives in low bits
        if f2 == face then              -- only connect to dust on the same face
          mask = setbit(mask, d.bit)
        end
      else
        -- Cosmetic: draw arm into any non-air neighbor (redstone look).
        if n.name ~= "air" then
          mask = setbit(mask, d.bit)
        end
      end
    end
  end
  return mask
end

local function apply_mask(pos, base, face)
  local mask   = compute_mask(pos, face)
  local target = ("%s_f%d_m%d"):format(base, face, mask)
  local n = minetest.get_node(pos)
  if n.name ~= target then
    local tint = math.floor(n.param2 / 32)
    minetest.swap_node(pos, {name = target, param2 = face + tint * 32})
  end
end

local function update_neighbors(pos, base, face)
  apply_mask(pos, base, face)
  for _,d in ipairs(NEIGH[face] or {}) do
    local q  = {x=pos.x+d.dx, y=pos.y+d.dy, z=pos.z+d.dz}
    local nn = minetest.get_node_or_nil(q)
    if nn and is_wire(nn.name) then
      local base2 = nn.name:gsub("_f%d+_m%d+$","")
      local face2 = nn.param2 % 32
      apply_mask(q, base2, face2)
    end
  end
  cw_copperflow.bump(pos)
end

local function register_wire_family(basename, desc, tile, loss)
  for face = 0,5 do
    for mask = 0,15 do
      minetest.register_node(("%s_f%d_m%d"):format(basename, face, mask), {
        description = desc .. " (auto)",
        tiles = {tile},
        drawtype = "nodebox",
        node_box = FACE_BOXES[face][mask],
        use_texture_alpha = "clip",
        paramtype = "light",
        paramtype2 = "colorwallmounted",
        sunlight_propagates = true,
        walkable = false,
        palette = "cf_power_palette.png",
        groups = {
          snappy=1, oddly_breakable_by_hand=1,
          [G.wire]=1, [G.conductive]=1, [G.waxable]=1,
          not_in_creative_inventory=1
        },
        _cf_loss = loss,

        on_construct = function(pos)
          cw_copperflow.set_power(pos, 0, false)
          minetest.get_node_timer(pos):start(0.05)
        end,

        on_timer = function(pos)
          cw_copperflow.recompute_power(pos)
          local p = cw_copperflow.get_power(pos)
          cw_copperflow.set_color_preserve_orientation(pos, cw_copperflow.param2_from_power(p))
          return false
        end,

        after_place_node = function(pos, placer, itemstack, pointed)
          -- Force orientation to the clicked face and start as _m0
          local face = 1 -- default floor
          if pointed and pointed.type == "node" then
            face = minetest.dir_to_wallmounted(vector.subtract(pointed.under, pointed.above))
          end
          local n = minetest.get_node(pos)
          local tint = math.floor(n.param2 / 32)
          minetest.swap_node(pos, {name=("%s_f%d_m0"):format(basename, face), param2 = face + tint*32})
          update_neighbors(pos, basename, face)
        end,

        after_dig_node = function(pos)
          -- Recompute masks around
          for dx=-1,1 do for dy=-1,1 do for dz=-1,1 do
            local q = {x=pos.x+dx,y=pos.y+dy,z=pos.z+dz}
            local nn = minetest.get_node_or_nil(q)
            if nn and is_wire(nn.name) then
              local base2 = nn.name:gsub("_f%d+_m%d+$","")
              local face2 = nn.param2 % 32
              apply_mask(q, base2, face2)
              cw_copperflow.bump(q)
            end
          end end end
        end,
      })
    end
  end

  -- The inventory item: places “_f<face>_m0” on the clicked face
  minetest.register_craftitem(basename.."_item", {
    description = desc,
    inventory_image = (basename:find("insulated") and "cf_wire_insulated_item.png" or "cf_wire_item.png"),
    on_place = function(stack, placer, pointed)
      if pointed and pointed.type == "node" then
        local face = minetest.dir_to_wallmounted(vector.subtract(pointed.under, pointed.above))
        local pos  = pointed.above
        local tint = 0
        local name = ("%s_f%d_m0"):format(basename, face)
        minetest.set_node(pos, {name=name, param2 = face + tint*32})
        update_neighbors(pos, basename, face)
        if not minetest.is_creative_enabled(placer:get_player_name()) then stack:take_item() end
        return stack
      end
      return minetest.item_place(stack, placer, pointed)
    end
  })
end

-- Families
register_wire_family("cw_copperflow:copper_wire",     "Copper Wire",            "cf_wire.png",           1)
register_wire_family("cw_copperflow:insulated_wire",  "Insulated Copper Wire",  "cf_wire_insulated.png", 0)
